import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

public class RoboEtapaQuatroV2 extends JPanel {

    int linhas  = 9;
    int colunas = 10;

    int linha  = 0;
    int coluna = 5;

    int linhaAnterior  = -1;
    int colunaAnterior = -1;

    int linhaFinal  = 8;
    int colunaFinal = 5;

    int passos = 0;
    int custoTotal = 0;
    boolean finalizado = false;

    boolean[][] visitado = new boolean[linhas][colunas];

    int[][] custosReais = {
        {1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 3, 1, 1, 1, 1},
        {1, 1, 2, 2, 1, 3, 3, 2, 1, 1},
        {1, 1, 2, 1, 3, 3, 3, 2, 1, 1},
        {1, 1, 2, 2, 3, 3, 3, 2, 2, 1},
        {1, 1, 1, 1, 2, 3, 1, 2, 2, 1},
        {1, 1, 1, 1, 1, 2, 3, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 0, 1, 1, 1, 1}
    };

    int[][] custosConhecidos = new int[linhas][colunas];
    boolean[][] revelado     = new boolean[linhas][colunas];

    List<int[]> caminho = new ArrayList<>();
    int indiceCaminho = 0;

    public RoboEtapaQuatroV2() {
        for (int i = 0; i < linhas; i++)
            Arrays.fill(custosConhecidos[i], 1);

        custosConhecidos[linha][coluna] = custosReais[linha][coluna];
        revelado[linha][coluna] = true;
        visitado[linha][coluna] = true;

        revelarVizinhos();

        // primeiro movimento aleatório
        List<int[]> vizinhosLivres = new ArrayList<>();
        int[] dl = {-1, 1, 0, 0};
        int[] dc = {0, 0, 1, -1};
        for (int d = 0; d < 4; d++) {
            int nl = linha + dl[d];
            int nc = coluna + dc[d];
            if (nl >= 0 && nl < linhas && nc >= 0 && nc < colunas) {
                vizinhosLivres.add(new int[]{nl, nc});
            }
        }
        int[] primeiraCasa = vizinhosLivres.get((int)(Math.random() * vizinhosLivres.size()));
        linhaAnterior  = linha;
        colunaAnterior = coluna;
        linha  = primeiraCasa[0];
        coluna = primeiraCasa[1];
        passos++;
        custoTotal += custosReais[linha][coluna];
        visitado[linha][coluna] = true;
        custosConhecidos[linha][coluna] = custosReais[linha][coluna];
        revelado[linha][coluna] = true;

        caminho = dijkstra(linha, coluna, linhaFinal, colunaFinal);
    }

    public static void main(String[] args) {
        JFrame janela = new JFrame("Robo Etapa 4 - Variação 2");
        RoboEtapaQuatroV2 painel = new RoboEtapaQuatroV2();
        janela.add(painel);
        janela.setSize(550, 580);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);

        Timer timer = new Timer(400, e -> {
            painel.mover();
            painel.repaint();
        });
        timer.start();
    }

    List<int[]> dijkstra(int li, int ci, int lf, int cf) {
        int total = linhas * colunas;
        int[] distancia = new int[total];
        int[][] anterior = new int[total][2];
        Arrays.fill(distancia, Integer.MAX_VALUE);
        for (int[] a : anterior) Arrays.fill(a, -1);

        distancia[li * colunas + ci] = 0;

        PriorityQueue<int[]> fila = new PriorityQueue<>((a, b) -> a[0] - b[0]);
        fila.add(new int[]{0, li, ci});

        int[] dl = {-1, 1, 0, 0};
        int[] dc = {0, 0, 1, -1};

        while (!fila.isEmpty()) {
            int[] atual = fila.poll();
            int custo = atual[0], l = atual[1], c = atual[2];

            if (l == lf && c == cf) break;
            if (custo > distancia[l * colunas + c]) continue;

            for (int d = 0; d < 4; d++) {
                int nl = l + dl[d];
                int nc = c + dc[d];
                if (nl >= 0 && nl < linhas && nc >= 0 && nc < colunas) {
                    int novoCusto = custo + custosConhecidos[nl][nc];
                    int idx = nl * colunas + nc;
                    if (novoCusto < distancia[idx]) {
                        distancia[idx] = novoCusto;
                        anterior[idx] = new int[]{l, c};
                        fila.add(new int[]{novoCusto, nl, nc});
                    }
                }
            }
        }

        List<int[]> resultado = new ArrayList<>();
        int[] pos = {lf, cf};
        while (pos[0] != -1) {
            resultado.add(0, pos);
            int idx = pos[0] * colunas + pos[1];
            pos = anterior[idx];
        }
        return resultado;
    }

    void revelarVizinhos() {
        int[] dl = {-1, 1, 0, 0};
        int[] dc = {0, 0, 1, -1};

        for (int d = 0; d < 4; d++) {
            int nl = linha + dl[d];
            int nc = coluna + dc[d];

            if (nl == linhaAnterior && nc == colunaAnterior) continue;

            if (nl >= 0 && nl < linhas && nc >= 0 && nc < colunas) {
                if (!revelado[nl][nc]) {
                    custosConhecidos[nl][nc] = custosReais[nl][nc];
                    revelado[nl][nc] = true;
                }

                // revela também a casa além de cada vizinho
                int nl2 = nl + dl[d];
                int nc2 = nc + dc[d];
                if (nl2 >= 0 && nl2 < linhas && nc2 >= 0 && nc2 < colunas) {
                    if (!revelado[nl2][nc2]) {
                        custosConhecidos[nl2][nc2] = custosReais[nl2][nc2];
                        revelado[nl2][nc2] = true;
                    }
                }
            }
        }
    }

    void mover() {
        if (finalizado) return;

        revelarVizinhos();

        caminho = dijkstra(linha, coluna, linhaFinal, colunaFinal);
        indiceCaminho = 0;

        if (caminho.isEmpty() || caminho.size() <= 1) {
            finalizado = true;
            return;
        }

        linhaAnterior  = linha;
        colunaAnterior = coluna;

        int[] proxima = caminho.get(1);
        linha  = proxima[0];
        coluna = proxima[1];
        passos++;

        if (linha != linhaFinal || coluna != colunaFinal) {
            visitado[linha][coluna] = true;
            custoTotal += custosReais[linha][coluna];
        }

        custosConhecidos[linha][coluna] = custosReais[linha][coluna];
        revelado[linha][coluna] = true;

        if (linha == linhaFinal && coluna == colunaFinal) {
            finalizado = true;
        }
    }

    Color corCelula(int i, int j) {
        if (!revelado[i][j]) return new Color(180, 180, 180);
        int custo = custosConhecidos[i][j];
        if (custo == 3) return new Color(220, 50, 50);
        if (custo == 2) return new Color(255, 200, 0);
        return new Color(100, 200, 100);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int tamanhoCell = 48;
        int margem = 10;

        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                int x = margem + j * tamanhoCell;
                int y = margem + i * tamanhoCell;

                if (i == linha && j == coluna) {
                    g.setColor(Color.BLUE);
                } else if (i == linhaFinal && j == colunaFinal) {
                    g.setColor(Color.RED);
                } else if (i == linhaAnterior && j == colunaAnterior) {
                    g.setColor(new Color(200, 200, 255));
                } else if (visitado[i][j]) {
                    g.setColor(new Color(173, 216, 230));
                } else {
                    g.setColor(corCelula(i, j));
                }

                g.fillRect(x, y, tamanhoCell, tamanhoCell);
                g.setColor(Color.BLACK);
                g.drawRect(x, y, tamanhoCell, tamanhoCell);

                if (i == 0 && j == 5) {
                    g.setColor(Color.BLACK);
                    g.drawString("i", x + 20, y + 30);
                } else if (i == linhaFinal && j == colunaFinal) {
                    g.setColor(Color.WHITE);
                    g.drawString("f", x + 20, y + 30);
                } else if (!revelado[i][j]) {
                    g.setColor(Color.DARK_GRAY);
                    g.drawString("?", x + 20, y + 30);
                } else {
                    g.setColor(Color.BLACK);
                    g.drawString(String.valueOf(custosConhecidos[i][j]), x + 20, y + 30);
                }
            }
        }

        int baseY = margem + linhas * tamanhoCell + 15;
        g.setColor(Color.BLACK);
        g.drawString("Variação 2 | Passos: " + passos + " | Custo total: " + custoTotal, margem, baseY);
        g.drawString("Posição: (" + linha + "," + coluna + ") | Destino: (" + linhaFinal + "," + colunaFinal + ")", margem, baseY + 20);

        if (finalizado && !caminho.isEmpty()) {
            g.setColor(new Color(0, 130, 0));
            g.drawString("Objetivo alcançado! Custo: " + custoTotal + " | Passos: " + passos, margem, baseY + 40);
        }

        if (caminho.isEmpty()) {
            g.setColor(Color.RED);
            g.drawString("Nenhum caminho encontrado!", margem, baseY + 40);
        }
    }
}
