import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class RoboEtapaTres extends JPanel {

    int tamanho = 10;
    int linha  = 0;
    int coluna = 0;
    int linhaFinal  = 7;
    int colunaFinal = 7;
    int passos = 0;
    boolean finalizado = false;

    boolean[][] visitado   = new boolean[tamanho][tamanho];
    boolean[][] obstaculos = new boolean[tamanho][tamanho];

    List<int[]> caminho = new ArrayList<>();
    int indiceCaminho = 0;

    public RoboEtapaTres() {
        obstaculos[0][4] = true;
        obstaculos[1][0] = true;
        obstaculos[1][3] = true;
        obstaculos[2][2] = true;
        obstaculos[3][2] = true;
        obstaculos[3][5] = true;
        obstaculos[4][1] = true;
        obstaculos[4][6] = true;
        obstaculos[5][3] = true;
        obstaculos[5][5] = true;
        obstaculos[5][6] = true;
        obstaculos[5][7] = true;
        obstaculos[5][8] = true;
        obstaculos[6][5] = true;
        obstaculos[6][7] = true;
        obstaculos[6][8] = true;
        obstaculos[7][5] = true;
        obstaculos[7][8] = true;
        obstaculos[8][5] = true;
        obstaculos[8][7] = true;
        obstaculos[8][8] = true;
        obstaculos[9][5] = true;

        visitado[linha][coluna] = true;
        caminho = bfs(linha, coluna, linhaFinal, colunaFinal);
    }

    public static void main(String[] args) {
        JFrame janela = new JFrame("Robo Etapa 3");
        RoboEtapaTres painel = new RoboEtapaTres();
        janela.add(painel);
        janela.setSize(500, 560);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);

        Timer timer = new Timer(300, e -> {
            painel.mover();
            painel.repaint();
        });
        timer.start();
    }

    List<int[]> bfs(int linhaInicio, int colunaInicio, int linhaObjetivo, int colunaObjetivo) {
        Queue<int[]> fila = new LinkedList<>();
        int[][] anterior = new int[tamanho * tamanho][2];
        boolean[] visitadoBFS = new boolean[tamanho * tamanho];

        for (int[] a : anterior) Arrays.fill(a, -1);

        int inicio = linhaInicio * tamanho + colunaInicio;
        fila.add(new int[]{linhaInicio, colunaInicio});
        visitadoBFS[inicio] = true;

        int[] dl = {-1, 1, 0, 0};
        int[] dc = {0, 0, 1, -1};

        while (!fila.isEmpty()) {
            int[] atual = fila.poll();
            int l = atual[0], c = atual[1];

            if (l == linhaObjetivo && c == colunaObjetivo) {
                List<int[]> resultado = new ArrayList<>();
                int[] pos = {linhaObjetivo, colunaObjetivo};
                while (pos[0] != -1) {
                    resultado.add(0, pos);
                    int idx = pos[0] * tamanho + pos[1];
                    pos = anterior[idx];
                }
                return resultado;
            }

            for (int d = 0; d < 4; d++) {
                int nl = l + dl[d];
                int nc = c + dc[d];
                int idx = nl * tamanho + nc;
                if (nl >= 0 && nl < tamanho && nc >= 0 && nc < tamanho
                        && !obstaculos[nl][nc] && !visitadoBFS[idx]) {
                    visitadoBFS[idx] = true;
                    anterior[idx] = new int[]{l, c};
                    fila.add(new int[]{nl, nc});
                }
            }
        }

        return new ArrayList<>();
    }

    void mover() {
        if (finalizado) return;

        if (caminho.isEmpty() || indiceCaminho >= caminho.size() - 1) {
            finalizado = true;
            return;
        }

        indiceCaminho++;
        int[] proxima = caminho.get(indiceCaminho);
        linha  = proxima[0];
        coluna = proxima[1];
        passos++;

        if (linha != linhaFinal || coluna != colunaFinal) {
            visitado[linha][coluna] = true;
        }

        if (linha == linhaFinal && coluna == colunaFinal) {
            finalizado = true;
        }
    }

    int contarVisitadas() {
        int count = 0;
        for (int i = 0; i < tamanho; i++)
            for (int j = 0; j < tamanho; j++)
                if (visitado[i][j]) count++;
        return count;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int tamanhoCell = 45;
        int margem = 10;

        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                int x = margem + j * tamanhoCell;
                int y = margem + i * tamanhoCell;

                if (obstaculos[i][j]) {
                    g.setColor(new Color(50, 50, 150));
                } else if (i == linha && j == coluna) {
                    g.setColor(Color.BLUE);
                } else if (i == linhaFinal && j == colunaFinal) {
                    g.setColor(Color.RED);
                } else if (visitado[i][j]) {
                    g.setColor(new Color(173, 216, 230));
                } else {
                    g.setColor(Color.WHITE);
                }

                g.fillRect(x, y, tamanhoCell, tamanhoCell);
                g.setColor(Color.BLACK);
                g.drawRect(x, y, tamanhoCell, tamanhoCell);
            }
        }

        g.setColor(Color.BLACK);
        g.drawString("Passos: " + passos + "  | Posição: (" + linha + ", " + coluna + ")", margem, 475);
        g.drawString("Destino: (" + linhaFinal + ", " + colunaFinal + ")  | Visitadas: " + contarVisitadas(), margem, 500);

        if (finalizado && !caminho.isEmpty()) {
            g.setColor(new Color(0, 130, 0));
            g.drawString("Objetivo alcançado em " + passos + " passos!", margem, 525);
        }

        if (caminho.isEmpty()) {
            g.setColor(Color.RED);
            g.drawString("Nenhum caminho encontrado!", margem, 525);
        }
    }
}
