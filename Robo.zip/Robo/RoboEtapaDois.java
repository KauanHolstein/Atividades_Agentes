import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class RoboEtapaDois extends JPanel {

    int tamanho = 10;
    int linha  = 0;
    int coluna = 0;
    int passos = 0;
    boolean finalizado = false;
    String direcaoAtual = "leste";

    boolean[][] visitado   = new boolean[tamanho][tamanho];
    boolean[][] obstaculos = new boolean[tamanho][tamanho];

    public RoboEtapaDois() {
        obstaculos[0][4] = true;
        obstaculos[1][0] = true;
        obstaculos[1][3] = true;
        obstaculos[2][2] = true;
        obstaculos[3][2] = true;
        obstaculos[3][5] = true;
        obstaculos[4][1] = true;
        obstaculos[4][6] = true;
        obstaculos[5][3] = true;
        obstaculos[5][5] = true;
        obstaculos[5][6] = true;
        obstaculos[5][7] = true;
        obstaculos[5][8] = true;
        obstaculos[6][5] = true;
        obstaculos[6][7] = true;
        obstaculos[6][8] = true;
        obstaculos[7][5] = true;
        obstaculos[7][8] = true;
        obstaculos[8][5] = true;
        obstaculos[8][7] = true;
        obstaculos[8][8] = true;
        obstaculos[9][5] = true;

        visitado[linha][coluna] = true;
    }

    public static void main(String[] args) {
        JFrame janela = new JFrame("Robo Etapa 2");
        RoboEtapaDois painel = new RoboEtapaDois();
        janela.add(painel);
        janela.setSize(500, 560);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);

        Timer timer = new Timer(300, e -> {
            painel.mover();
            painel.repaint();
        });
        timer.start();
    }

    void mover() {
        if (finalizado) return;

        ArrayList<String> opcoes       = new ArrayList<>();
        ArrayList<String> naoVisitadas = new ArrayList<>();

        String[] direcoes = {"norte", "sul", "leste", "oeste"};

        for (String dir : direcoes) {
            int novaLinha  = linha;
            int novaColuna = coluna;
            if (dir.equals("norte")) novaLinha--;
            if (dir.equals("sul"))   novaLinha++;
            if (dir.equals("leste")) novaColuna++;
            if (dir.equals("oeste")) novaColuna--;

            if (novaLinha >= 0 && novaLinha < tamanho &&
                novaColuna >= 0 && novaColuna < tamanho &&
                !obstaculos[novaLinha][novaColuna]) {
                opcoes.add(dir);
                if (!visitado[novaLinha][novaColuna]) {
                    naoVisitadas.add(dir);
                }
            }
        }

        if (opcoes.isEmpty()) {
            finalizado = true;
            return;
        }

        ArrayList<String> lista = naoVisitadas.isEmpty() ? opcoes : naoVisitadas;
        String escolha = lista.get((int)(Math.random() * lista.size()));

        if (escolha.equals("norte")) linha--;
        if (escolha.equals("sul"))   linha++;
        if (escolha.equals("leste")) coluna++;
        if (escolha.equals("oeste")) coluna--;
        passos++;
        visitado[linha][coluna] = true;
        direcaoAtual = escolha;
    }

    int contarVisitadas() {
        int count = 0;
        for (int i = 0; i < tamanho; i++)
            for (int j = 0; j < tamanho; j++)
                if (visitado[i][j]) count++;
        return count;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int tamanhoCell = 45;
        int margem = 10;

        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                int x = margem + j * tamanhoCell;
                int y = margem + i * tamanhoCell;

                if (obstaculos[i][j]) {
                    g.setColor(new Color(50, 50, 150));
                } else if (i == linha && j == coluna) {
                    g.setColor(Color.BLUE);
                } else if (visitado[i][j]) {
                    g.setColor(new Color(173, 216, 230));
                } else {
                    g.setColor(Color.WHITE);
                }

                g.fillRect(x, y, tamanhoCell, tamanhoCell);
                g.setColor(Color.BLACK);
                g.drawRect(x, y, tamanhoCell, tamanhoCell);
            }
        }

        g.setColor(Color.BLACK);
        g.drawString("Passos: " + passos + "  | Posição: (" + linha + ", " + coluna + ")", margem, 475);
        g.drawString("Células visitadas: " + contarVisitadas() + " | Direção: " + direcaoAtual, margem, 500);

        if (finalizado) {
            g.setColor(new Color(0, 130, 0));
            g.drawString("Exploração concluída em " + passos + " passos!", margem, 525);
        }
    }
}
