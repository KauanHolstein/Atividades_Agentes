import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class RoboEtapaUm extends JPanel {

    int tamanho = 10;
    int linha = (int)(Math.random() * 10);
    int coluna = (int)(Math.random() * 10);
    int passos = 0;

    boolean norte = false;
    boolean sul = false;
    boolean leste = false;
    boolean oeste = false;

    public static void main(String[] args) {
        JFrame janela = new JFrame("Robo Etapa 1");
        RoboEtapaUm painel = new RoboEtapaUm();
        janela.add(painel);
        janela.setSize(500, 560);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);

        Timer timer = new Timer(300, e -> {
            painel.mover();
            painel.repaint();
        });
        timer.start();
    }

    void mover() {
        norte = (linha == 0);
        sul    = (linha == tamanho - 1);
        leste  = (coluna == tamanho - 1);
        oeste  = (coluna == 0);

        if (norte && sul && leste && oeste) return;

        ArrayList<String> opcoes = new ArrayList<>();
        if (linha > 0)            opcoes.add("norte");
        if (linha < tamanho - 1)  opcoes.add("sul");
        if (coluna < tamanho - 1) opcoes.add("leste");
        if (coluna > 0)           opcoes.add("oeste");

        String escolha = opcoes.get((int)(Math.random() * opcoes.size()));

        if (escolha.equals("norte")) linha--;
        if (escolha.equals("sul"))   linha++;
        if (escolha.equals("leste")) coluna++;
        if (escolha.equals("oeste")) coluna--;
        passos++;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        int tamanhoCell = 45;
        int margem = 10;

        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                int x = margem + j * tamanhoCell;
                int y = margem + i * tamanhoCell;

                if (i == linha && j == coluna) {
                    g.setColor(Color.BLUE);
                } else {
                    g.setColor(Color.WHITE);
                }

                g.fillRect(x, y, tamanhoCell, tamanhoCell);
                g.setColor(Color.BLACK);
                g.drawRect(x, y, tamanhoCell, tamanhoCell);
            }
        }

        g.setColor(Color.BLACK);
        g.drawString("Passos: " + passos + "  | Posição: (" + linha + ", " + coluna + ")", margem, 475);
        g.drawString(
            "Norte: " + (norte ? "✅" : "❌") + "  " +
            "Sul: "   + (sul   ? "✅" : "❌") + "  " +
            "Leste: " + (leste ? "✅" : "❌") + "  " +
            "Oeste: " + (oeste ? "✅" : "❌"),
            margem, 500
        );
    }
}
